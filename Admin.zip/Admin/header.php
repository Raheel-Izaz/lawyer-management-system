<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="dashboard.css">
</head>

<body>

    <body id="body-pd">
        <header class="header" id="header">
            <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
            <div class="header_home"> <a href="../index.php"><button class="btn btn-primary">Home</button></a> </div>
            <div class="header_img"> <img src="https://i.imgur.com/hczKIze.jpg" alt=""> </div>
        </header>
        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
                <div> <a href="admin_dashboard.php" class="nav_logo"> <i class='bx bx-layer nav_logo-icon'></i> <span class="nav_logo-name">Admin Dashboard</span> </a>
                    <div class="nav_list">
                        <a href="admin_dashboard.php" class="nav_link active"> <i class='bx bx-grid-alt nav_icon'></i> <span class="nav_name">Dashboard</span> </a>
                        <a href="add-lawyer.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Add Lawyer</span> </a>
                        <a href="lawyers.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Our Lawyers</span> </a>
                        <a href="users.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Users</span> </a>
                        <a href="add-city.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">City</span> </a>
                        <a href="add-specialty.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Specialty</span> </a>

                    </div>
                </div> <a href="logout.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">Logout</span> </a>
            </nav>
        </div>

        <script src="dashboard.js"></script>
    </body>

</html>