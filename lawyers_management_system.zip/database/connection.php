<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $db_name = "lawyers_management_system";

    $conn = mysqli_connect($server , $user , $password, $db_name );

    $host = "http://localhost/Lawyer-app";

?>