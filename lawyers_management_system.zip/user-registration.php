<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
    <title>User Registration</title>
</head>

<body>
    <?php
    include "header.php";

    ?>
    <div class="appointment_area">
        <div class="container">
            <div class="row align-items-center ">
                <div class="col-xl-12 offset-xl-1 col-md-12 col-md-12 col-lg-12">
                    <div class="appointment_info">
                        <div class="opacity_icon d-none d-lg-block">
                            <i class="flaticon-balance"></i>
                        </div>
                        <h3 class="mb-5">Client Registration</h3>
                        <form action="save-user-registration.php" method="post">
                            <div class="row mb-5">
                                <div class="col-xl-12 col-md-12">
                                    <input type="text" name="name" placeholder="Name">
                                </div>
                                <div class="col-xl-12 col-md-12">
                                    <input type="text" name="phone" placeholder="Phone">
                                </div>
                                <div class="col-xl-12 col-md-12">
                                    <input type="email" name="email" placeholder="Email">
                                </div>
                                <div class="col-xl-12 col-md-12">
                                    <input type="password" name="password" placeholder="Password">
                                </div>
                                <div class="col-xl-12 col-md-12 mb-3">
                                    <div class="container-xxl">
                                        <select name="city" class="form-select border border-warning" aria-label="Default select example">
                                            <option selected >Select City</option>
                                            <option value="karachi">Karachi</option>
                                            <option value="peshawar">Peshawar</option>
                                            <option value="islamabad">Islamabad</option>
                                            <option value="lahore">Lahore</option>
                                            <option value="punjab">Punjab</option>
                                            <option value="paris">Paris</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-3">
                                    <div class="appoinment_button">
                                        <button class="boxed-btn5" name="register" type="submit">Register</button>
                                    </div>
                                </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php
    include "footer.php";

    ?>
    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/gijgo.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/plugins.js"></script>

    <!--contact js-->
    <script src="js/contact.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/mail-script.js"></script>

    <script src="js/main.js"></script>

</body>

</html>